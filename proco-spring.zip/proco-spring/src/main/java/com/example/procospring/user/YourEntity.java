package com.example.procospring.user;

public class YourEntity {

    // 필드 정의
    private String exampleField;

    // 생성자 정의
    public YourEntity() {
        // 생성자 구현
    }

    // Getter와 Setter 메서드 정의
    public String getExampleField() {
        return exampleField;
    }

    public void setExampleField(String exampleField) {
        this.exampleField = exampleField;
    }
}
